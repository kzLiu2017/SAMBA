#include "test_so.h"
#include "test_so_1.h"

int main(){
	printf("hello world");
	no_ssl_api();
	no_ssl_api_1();
}