#include "test_so_1.h"

void no_ssl_api_1(){
	int i = 0;
	i = i + 1;
	printf("1");
	ssl_api_1();
}