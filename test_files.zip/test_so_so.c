#include "test_so_so.h"
void ssl_api(){
	SSL_METHOD *method;
	method = TLSv1_2_client_method();
	printf("123\n");
}